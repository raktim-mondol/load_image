from data_class import Data



IMAGE_PATH = './train_folder/'
#must include forward slash in the end

data_obj= Data()
# You can provide your desired image size
# You can upscale or downscale

X_train, Y_train = data_obj.load_segmentation_data(IMAGE_PATH, 'tif', 256, 256)

# Visualize image with corresponding mask
data_obj.visualize(X_train,Y_train)
#The above line will randomly visualize 
#so run above code as much as you need 
