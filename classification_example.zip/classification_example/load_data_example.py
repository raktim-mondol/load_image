from data_class import Data
IMAGE_PATH = './train_folder/'
#must include forward slash in the end

data_obj= Data()
# You can provide your desired image size
# You can upscale or downscale

X_train, Y_train = data_obj.load_classification_data(IMAGE_PATH, 'jpg', 256, 256, to_cat=True)

#Check Data Label
data_obj.label_check()

# Visualize image with corresponding mask
data_obj.visualize(X_train)
